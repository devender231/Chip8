/**
 1 2 3 4
 Q W E R
 A S D F
 Z X C V 
*/

const keyMap = ['1', '2', '3', '4', 'q', 'w', 'e', 'r', 'a', 's', 'd', 'f', 'z', 'x', 'c', 'v']

module.exports = keyMap
