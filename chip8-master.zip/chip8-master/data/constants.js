const DISPLAY_WIDTH = 64
const DISPLAY_HEIGHT = 32
const COLOR = '#33ff66'

module.exports = {
  DISPLAY_WIDTH,
  DISPLAY_HEIGHT,
  COLOR,
}
